#include <stdio.h>
#include "funciones_grupo.h"
int main(int argc, char* argv[])
{
    return solucion(argc, argv);
}
